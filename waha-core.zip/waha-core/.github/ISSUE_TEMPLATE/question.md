---
name: Question
about: I have a question about the project or feature
title: '[Question] '
labels: 'question'
assignees: ''
---

👉 Kindly use
[GitHub Discussions](https://github.com/devlikeapro/waha/discussions) to ask
questions!

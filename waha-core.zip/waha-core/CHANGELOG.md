# Changelog

You can find changelog on
[the changelog page](https://waha.devlike.pro/docs/help/changelog/)
